import java.util.*;

public class Storefront {
    public static void main(String[] args) {

    }
}
